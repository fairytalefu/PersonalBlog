<?php
/**
 * Created by PhpStorm.
 * User: lufficc
 * Date: 2017/3/4
 * Time: 15:30
 */

namespace Lufficc\Exception;

use Exception;

class UnConfigurableException extends Exception
{

}