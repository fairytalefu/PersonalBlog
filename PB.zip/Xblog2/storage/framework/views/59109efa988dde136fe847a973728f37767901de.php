<?php $__env->startSection('title','标签 文章'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('post.index')); ?>">博客</a></li>
            <li><a href="<?php echo e(route('tag.index')); ?>">标签</a></li>
            <li class="active"><?php echo e($name); ?></li>
        </ol>
        <div class="row">
            <div class="col-md-8">
                <?php if($posts->isEmpty()): ?>
                    <?php echo $__env->make('partials.empty', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php else: ?>
                    <?php echo $__env->renderEach('post.item',$posts,'post'); ?>
                    <?php if($posts->lastPage() > 1): ?>
                        <?php echo e($posts->links()); ?>

                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="col-md-4">
                <?php echo $__env->make('layouts.widgets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>