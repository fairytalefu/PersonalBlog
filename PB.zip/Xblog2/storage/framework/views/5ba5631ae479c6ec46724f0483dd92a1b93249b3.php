<div class="widget widget-default">
    <div class="widget-header"><h6><i class="fa fa-tags fa-fw"></i>标签</h6></div>
    <ul class="widget-body">
        <div class="tag-list">
            <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if(str_contains(urldecode(request()->getPathInfo()),'tag/'.$tag->name)): ?>
                    <span class="tag tag-active" title="<?php echo e($tag->name); ?>">
                        <?php echo e($tag->name); ?>

                        <span class="badge badge-active"><?php echo e($tag->posts_count); ?></span>
                    </span>
                <?php else: ?>
                    <a  title="<?php echo e($tag->name); ?>" href="<?php echo e(route('tag.show',$tag->name)); ?>" class="tag">
                        <?php echo e($tag->name); ?>

                        <span class="badge"><?php echo e($tag->posts_count); ?></span>
                    </a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <p class="meta-item center-block">No tags.</p>
            <?php endif; ?>
        </div>
    </ul>
</div>