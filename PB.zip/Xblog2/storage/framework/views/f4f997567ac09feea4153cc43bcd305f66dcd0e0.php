<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="theme-color" content="#52768e">
    <title><?php echo $__env->yieldContent('title'); ?> Admin <?php echo e(isset($site_title) ? $site_title : ''); ?></title>
    <link href="//cdn.bootcss.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
    <?php if(isset($site_css) && $site_css): ?>
        <link href="<?php echo e($site_css); ?>" rel="stylesheet">
    <?php else: ?>
        <link href="<?php echo e(elixir('css/app.css')); ?>" rel="stylesheet">
    <?php endif; ?>
    <?php echo $__env->yieldContent('css'); ?>
    <script>
        window.XblogConfig = <?php echo json_encode([
                'csrfToken' => csrf_token(),
                'github_username' => isset($github_username) ? $github_username :  '',
        ]);?>
    </script>
</head>
<body>
<?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="content-wrap">
    <div class="container">
        <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('partials.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php if(isset($site_js) && $site_js): ?>
    <script src="<?php echo e($site_js); ?>"></script>
<?php else: ?>
    <script src="<?php echo e(elixir('js/app.js')); ?>"></script>
<?php endif; ?>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
