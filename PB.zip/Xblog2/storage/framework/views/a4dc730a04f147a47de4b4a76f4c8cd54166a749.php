<?php if(!$recommendedPosts->isEmpty()): ?>
    <div class="alert alert-dismissable alert-info"
         style="background-color: #fff;color:inherit;padding:15px 20px 10px;border-color:#ededed;border-radius: 0">
        <button style="margin-right: 20px" type="button" class="close" data-dismiss="alert"
                aria-hidden="true">&times;</button>
        <label>推荐阅读 :</label>
        <?php $__currentLoopData = $recommendedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="padding-top: 5px;padding-bottom: 5px;">
                <a style="font-size: 1.15em" href="<?php echo e(route("post.show",$post->slug)); ?>"><?php echo e(str_limit($post->title,36)); ?></a>
                <span style="color: #ccc;margin-left: 15px;"><?php echo e($post->created_at->format('Y-m-d')); ?></span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>