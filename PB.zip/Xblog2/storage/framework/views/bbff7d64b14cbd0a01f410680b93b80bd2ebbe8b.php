<?php $__env->startSection('title','归档'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if($posts_count): ?>
            <div class="posts-count">共<?php echo e($posts_count); ?>篇文章</div>
            <div id="cd-timeline" class="cd-container" style="margin: 0 0">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cd-timeline-block">
                        <div class="cd-timeline-img cd-picture">
                        </div>
                        <div class="cd-timeline-content">
                            <a href="<?php echo e(route('post.show',$post->slug)); ?>">
                                <div class="title"><?php echo e($post->title); ?></div>
                            </a>
                            <span class="cd-date"><?php echo e($post->created_at->format('Y-m-d')); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="dot"></div>
        <?php else: ?>
            <p class="meta-item center-block">No posts.</p>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>