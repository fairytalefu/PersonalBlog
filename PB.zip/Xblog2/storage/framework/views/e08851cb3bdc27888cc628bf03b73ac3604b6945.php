<?php $__env->startSection('title','搜索'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <?php if($posts->count() == 0): ?>
                    <div class="widget widget-default">
                        <div class="widget-header">
                            <h3>搜索 "<?php echo e(request('q')); ?>"</h3>
                        </div>
                        <div class="widget-body">
                            <h4>什么也没搜到...</h4>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="widget widget-default">
                        <div class="widget-header">
                            <h3>Search for "<?php echo e(request('q')); ?>"</h3>
                        </div>
                    </div>
                    <?php echo $__env->renderEach('post.item',$posts,'post'); ?>
                    <?php if($posts->lastPage() > 1): ?>
                        <?php echo e($posts->links()); ?>

                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="col-md-4">
                <div class="slide">
                    <?php echo $__env->make('layouts.widgets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>