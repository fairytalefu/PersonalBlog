<?php $__env->startSection('title','博客'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="widget widget-default">
                    <div class="widget-header">
                        <h6><i class="fa fa-comments fa-fw"></i>
                            通知
                            <?php if($notifications->isNotEmpty()): ?>
                                <a class="btn btn-info" role="button" style="display: inline;margin-left: 20px"
                                   href="<?php echo e(route('user.readNotification',"all")); ?>">
                                    全部已读
                                </a>
                            <?php endif; ?>
                        </h6>
                    </div>
                    <div class="widget-body">
                        <?php if($notifications->isEmpty()): ?>
                            <h3 class="center-block meta-item">No Notifications</h3>
                        <?php else: ?>
                            <table class="table table-striped table-hover table-bordered table-responsive">
                                <thead>
                                <tr>
                                    <th>用户</th>
                                    <th>Email</th>
                                    <th>类型</th>
                                    <th>内容</th>
                                    <th>IP</th>
                                    <th>操作</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($notification->data): ?>
                                        <?php $notificationData = $notification->data?>
                                        <tr class="">
                                            <td>
                                                <?php if($notificationData['user_id']): ?>
                                                    <a href="<?php echo e(route('user.show',$notificationData['username'])); ?>"><?php echo e($notificationData['username']); ?></a>
                                                <?php else: ?>
                                                    <?php echo e($notificationData['username']); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="mailto:<?php echo e($notificationData['email']); ?>"><?php echo e($notificationData['email']); ?></a>
                                            </td>
                                            <td>
                                                <?php if("App\\Notifications\\ReceivedComment" == $notification->type): ?>
                                                    评论
                                                <?php elseif("App\\Notifications\\MentionedInComment" == $notification->type): ?>
                                                    提到了你
                                                <?php elseif("App\\Notifications\\BaseNotification" == $notification->type): ?>
                                                    基本提醒
                                                <?php endif; ?>
                                            </td>
                                            <td data-toggle="tooltip" data-placement="top"
                                                title="<?php echo e($notificationData['content']); ?>"><?php echo $notificationData['content']; ?></td>
                                            <td><?php echo e($notificationData['ip_id']?$notificationData['ip_id']:'NONE'); ?></td>
                                            <td>
                                                <a class="btn btn-info"
                                                   href="<?php echo e(route('user.readNotification',$notification->id)); ?>">
                                                    已读
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>