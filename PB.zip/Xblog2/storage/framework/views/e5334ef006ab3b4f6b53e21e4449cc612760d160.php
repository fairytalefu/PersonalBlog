<?php if(isset($background_image) && $background_image): ?>
    <style>
        @media  screen and (min-width: 768px) {
            .main-header {
                background: url("<?php echo e($background_image); ?>") no-repeat center center;
                background-size: 100% auto;
                position: static;
            }
        }
    </style>
<?php endif; ?>
<header class="main-header">
    <div class="container-fluid" style="margin-top: -15px">
        <nav class="navbar site-navbar" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                        data-target="#blog-navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="<?php echo e(route('post.index')); ?>"
                   class="navbar-brand"><?php echo e(isset($author) ? $author : 'Blog'); ?></a>
            </div>
            <div class="collapse navbar-collapse fix-top" id="blog-navbar-collapse">
                <ul class="nav navbar-nav">
                    <li><a class="menu-item" href="<?php echo e(route('achieve')); ?>">归档</a></li>
                    <?php if(XblogConfig::getValue('github_username')): ?>
                        <li><a class="menu-item" href="<?php echo e(route('projects')); ?>">项目</a></li>
                    <?php endif; ?>
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a class="menu-item"
                               href="<?php echo e(route('page.show',$page->name)); ?>"><?php echo e($page->display_name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <ul class="nav navbar-nav navbar-right blog-navbar">
                    <?php if(Auth::check()): ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <?php
                                $user = auth()->user();
                                $unreadNotificationsCount = $user->unreadNotifications->count();
                                ?>
                                <?php if($unreadNotificationsCount): ?>
                                    <span class="badge required"><?php echo e($unreadNotificationsCount); ?></span>
                                <?php endif; ?>
                                <?php echo e($user->name); ?>

                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="<?php echo e(route('user.show',auth()->user()->name)); ?>">个人中心</a></li>
                                <?php if(isAdmin(Auth::user())): ?>
                                    <li><a href="<?php echo e(route('admin.index')); ?>">后台管理</a></li>
                                <?php endif; ?>
                                <li><a href="<?php echo e(route('user.notifications')); ?>">
                                        <?php
                                        $user = auth()->user();
                                        $unreadNotificationsCount = $user->unreadNotifications->count();
                                        ?>
                                        <?php if($unreadNotificationsCount): ?>
                                            <span class="badge required"><?php echo e($unreadNotificationsCount); ?></span>
                                        <?php endif; ?>
                                        通知中心
                                    </a></li>
                                <li class="divider"></li>
                                <li><a href="<?php echo e(url('/logout')); ?>" onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                        退出登录
                                    </a>
                                </li>
                                <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST"
                                      style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li><a href="<?php echo e(url('login')); ?>">登录</a></li>
                        <li><a href="<?php echo e(url('register')); ?>">注册</a></li>
                    <?php endif; ?>
                </ul>
                <form class="navbar-form navbar-right" role="search" method="get" action="<?php echo e(route('search')); ?>">
                    <input type="text" class="form-control" name="q" placeholder="搜索" required>
                </form>
            </div>
        </nav>
    </div>
    <div class="container-fluid">
        <div class="description"><?php echo e(isset($description) ? $description : 'Stay Hungry. Stay Foolish.'); ?></div>
    </div>
</header>