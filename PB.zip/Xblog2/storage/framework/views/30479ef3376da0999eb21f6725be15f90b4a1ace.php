<div class="comments" id="comments">
    <div class="comments-body">
        <div id="comments-container"
             data-api-url="<?php echo e(route('comment.show',[$commentable->id,
             'commentable_type'=>$commentable_type,
             'redirect'=>(isset($redirect) && $redirect ? $redirect:'')])); ?>">
            <?php if(isset($comments) && !empty($comments)): ?>
                <?php echo $__env->make('comment.show',$comments, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        </div>
        <form id="comment-form" method="post" action="<?php echo e(route('comment.store')); ?>">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="commentable_id" value="<?php echo e($commentable->id); ?>">
            <input type="hidden" name="commentable_type" value="<?php echo e($commentable_type); ?>">
            <?php $final_allow_comment = $commentable->allowComment()?>
            <?php if(!auth()->check()): ?>
                <div class="form-group">
                    <label for="username">姓名<span class="required">*</span></label>
                    <input <?php echo e($final_allow_comment?' ':' disabled '); ?> class="form-control" id="username" type="text" name="username" placeholder="您的大名">
                </div>
                <div class="form-group">
                    <label for="email">邮箱<span class="required">*</span></label>
                    <input <?php echo e($final_allow_comment?' ':' disabled '); ?> class="form-control" id="email" type="email" name="email" placeholder="邮箱不会公开">
                </div>
                <div class="form-group">
                    <label for="site">个人网站</label>
                    <input <?php echo e($final_allow_comment?' ':' disabled '); ?> class="form-control" id="site" type="text" name="site" placeholder="可选，填写后点击头像可以直接进入">
                </div>
            <?php endif; ?>
            <div class="form-group">
                <label for="comment-content">评论内容<span class="required">*</span></label>
                <textarea <?php echo e($final_allow_comment?' ':' disabled '); ?> placeholder="支持Markdown" style="resize: vertical"
                          id="comment-content" name="content"
                          rows="5" spellcheck="false"
                          class="form-control markdown-content autosize-target"></textarea>
                <span class="help-block required">
                    <strong id="comment_error_msg"></strong>
                </span>
            </div>
            <div class="form-group">
                <input <?php echo e($final_allow_comment?' ':' disabled '); ?> type="submit" id="comment-submit" class="btn btn-more"
                       value="回复"/>
            </div>
        </form>
    </div>
</div>