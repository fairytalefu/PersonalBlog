<?php $__env->startSection('title','博客'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <?php if($posts->count()==0): ?>
                    <h3 class="meta-item center-block">NO POSTS.</h3>
                <?php else: ?>
                    <?php echo $__env->renderEach('post.item',$posts,'post'); ?>
                    <?php if($posts->lastPage() > 1): ?>
                        <?php echo e($posts->links()); ?>

                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="col-md-4">
                <div class="slide">
                    <?php echo $__env->make('layouts.widgets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>