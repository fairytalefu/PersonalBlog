<div class="widget widget-default">
    <div class="widget-header"><h6 style="font-weight: bold;"> <i class="fa fa-folder fa-fw"></i>文章分类</h6></div>
    <ul class="widget-body list-group">
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if(str_contains(urldecode(request()->getPathInfo()),'category/'.$category->name)): ?>
                <li title="<?php echo e($category->name); ?>" href="<?php echo e(route('category.show',$category->name)); ?>"
                    class="list-group-item active">
                   <?php echo e($category->name); ?>

                    <span class="badge"><?php echo e($category->posts_count); ?></span>
                </li>

            <?php else: ?>
                <a title="<?php echo e($category->name); ?>" href="<?php echo e(route('category.show',$category->name)); ?>"
                   class="list-group-item">
                    <?php echo e($category->name); ?>

                    <span class="badge"><?php echo e($category->posts_count); ?></span>
                </a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="meta-item center-block">No categories.</p>
        <?php endif; ?>
    </ul>
</div>