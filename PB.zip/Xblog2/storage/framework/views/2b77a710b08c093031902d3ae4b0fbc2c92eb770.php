<?php if(session()->has('success')): ?>
    <div class="alert alert-dismissable alert-success">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <ul>
            <?php echo session()->get('success'); ?>

        </ul>
    </div>
<?php endif; ?>