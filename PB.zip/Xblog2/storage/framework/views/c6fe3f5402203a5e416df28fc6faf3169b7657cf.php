<?php $__env->startSection('description',$post->description); ?>
<?php $__env->startSection('keywords',$post->category->name); ?>
<?php $__env->startSection('title',$post->title); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-sm-12 phone-no-padding">
                <div class="post-detail">
                    <div class="center-block">
                        <div class="post-detail-title"><?php echo e($post->title); ?></div>
                        <div class="post-meta">
                            <span class="post-category">
                           <i class="fa fa-folder-o fa-fw"></i>
                           <a href="<?php echo e(route('category.show',$post->category->name)); ?>">
                           <?php echo e($post->category->name); ?>

                           </a>
                           </span>
                            <span class="post-comments-count">
                           &nbsp;|&nbsp;
                           <i class="fa fa-comments-o fa-fw" aria-hidden="true"></i>
                           <span><?php echo e($post->comments_count); ?></span>
                           </span>
                            <span>
                           &nbsp;|&nbsp;
                           <i class="fa fa-eye"></i>
                           <span><?php echo e($post->view_count); ?></span>
                           </span>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$post)): ?>
                                <span>
                                    &nbsp;|&nbsp;
                                    <a href="<?php echo e(route('post.edit',$post->id)); ?>">
                                        <i class="fa fa-pencil fa-fw"></i>
                                    </a>
                                </span>
                                <span>
                                    &nbsp;|&nbsp;
                                    <a class="swal-dialog-target"
                                       data-url="<?php echo e(route('post.destroy',$post->id)); ?>"
                                       data-dialog-msg="Delete <?php echo e($post->title); ?> ?">
                                    <i class="fa fa-trash-o fa-fw"></i>
                                    </a>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="post-detail-content">
                        <?php echo $post->html_content; ?>

                        <p>-- END</p>
                        <?php echo $__env->make('widget.pay', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                    <div class="post-info-panel">
                        <p class="info">
                            <label class="info-title">版权声明:</label><i class="fa fa-fw fa-creative-commons"></i>自由转载-非商用-非衍生-保持署名（<a
                                    href="https://creativecommons.org/licenses/by-nc-nd/3.0/deed.zh">创意共享3.0许可证</a>）
                        </p>
                        <p class="info">
                            <label class="info-title">创建日期:</label><?php echo e($post->created_at->format('Y年m月d日')); ?>

                        </p>
                        <?php if(isset($post->published_at) && $post->published_at): ?>
                            <p class="info">
                                <label class="info-title">修改日期:</label><?php echo e($post->published_at->format('Y年m月d日')); ?>

                            </p>
                        <?php endif; ?>
                        <p class="info">
                            <label class="info-title">文章标签:</label>
                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="tag" href="<?php echo e(route('tag.show',$tag->name)); ?>"><?php echo e($tag->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                    </div>
                </div>
                <?php if(isset($recommendedPosts)): ?>
                    <?php echo $__env->make('widget.recommended_posts',['recommendedPosts'=>$recommendedPosts], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>
                <?php if(!(isset($preview) && $preview) && $post->isShownComment()): ?>
                    <?php echo $__env->make('widget.comment',[
                            'comment_key'=>$post->slug,
                            'comment_title'=>$post->title,
                            'comment_url'=>route('post.show',$post->slug),
                            'commentable'=>$post,
                            'comments'=>isset($comments) ? $comments:[],
                            'redirect'=>request()->fullUrl(),
                             'commentable_type'=>'App\Post'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>