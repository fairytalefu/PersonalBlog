<?php
$final_comment_type = $commentable->getCommentType();
?>
<?php if($final_comment_type == 'raw'): ?>
    <?php echo $__env->make('widget.raw_comment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php elseif($final_comment_type == 'duoshuo'): ?>
    <?php echo $__env->make('widget.duoshuo_comment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php elseif($final_comment_type == 'disqus'): ?>
    <?php echo $__env->make('widget.disqus_comment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>