<div class="widget widget-user" style="overflow: hidden">
    <?php
    if (isset($profile_image) && $profile_image)
        $style = "background: url($profile_image) center center;";
    else
        $style = "background-color: #52768e;";
    ?>
    <div class="widget-user-header" style="<?php echo e($style); ?>">
        <h3 class="widget-user-username"><?php echo e(isset($author) ? $author : 'Author'); ?></h3>
        <h5 class="widget-user-desc"><?php echo e(isset($description) ? $description : 'Description'); ?></h5>
    </div>
    <div class="widget-user-image">
        <img class="img-circle" src="<?php echo e(isset($avatar) ? $avatar : 'https://raw.githubusercontent.com/lufficc/images/master/Xblog/logo.png'); ?>" alt="User Avatar">
    </div>
    <div class="widget-user-footer">
        <div class="row">
            <?php $count = count(config('social'))?>
            <?php $__currentLoopData = config('social'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xs-<?php echo e(intval(12 / $count)); ?> border-right center-block">
                    <div class="description-block">
                        <a href="<?php echo e($value['url']); ?>" title="<?php echo e(ucfirst($key)); ?>" class="description-header"><i
                                    class="<?php echo e($value['fa'].' fa-lg'); ?>"
                                    aria-hidden="true"></i></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>