<!DOCTYPE html>
<html lang="Zh_cn" xmlns:v-on="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="<?php echo e(isset($author) ? $author : ''); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> <?php echo e(isset($site_title) ? $site_title : ''); ?> </title>
    <meta name="keywords" content="<?php echo e(isset($site_keywords) ? $site_keywords : ''); ?>">
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?> <?php echo e(isset($site_description) ? $site_description : ''); ?>">
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo e(isset($site_title) ? $site_title : ''); ?>">
    <meta property="og:site_name" content="<?php echo e(isset($site_title) ? $site_title : ''); ?>">
    <meta property="og:description" content="<?php echo e(isset($site_description) ? $site_description : ''); ?>">
    <meta name="theme-color" content="#52768e">
    <link href="//cdn.bootcss.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo e(elixir('css/home.css')); ?>" rel="stylesheet">
    <?php echo $__env->make('widget.google_analytics', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
<div class="container">
    <div class="content">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>
<?php echo $__env->yieldContent('js'); ?>
</body>
</html>
