<?php $__env->startSection('content'); ?>
    <div class="error">
        <div class="title">404</div>
        <p class="links">
            <a href="<?php echo e(route('post.index')); ?>" aria-label="点击查看博客文章列表">博客</a><font aria-hidden="true">/</font>
            <a href="<?php echo e(route('projects')); ?>" aria-label="点击查看项目列表">项目</a><font aria-hidden="true">/</font>
            <a href="<?php echo e(route('page.show','about')); ?>" aria-label="查看聪聪的个人信息">关于</a>
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>