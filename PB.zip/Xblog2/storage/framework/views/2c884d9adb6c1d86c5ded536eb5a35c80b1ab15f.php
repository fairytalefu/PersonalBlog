<?php echo $__env->make('widget.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php if(XblogConfig::getValue('enable_hot_posts') == 'true'): ?>
    <?php echo $__env->make('widget.hot_posts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
<?php echo $__env->make('widget.categories', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('widget.tags', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>