<?php $__env->startSection('title','评论'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="widget widget-default">
                <div class="widget-header">
                    <h6><i class="fa fa-comments fa-fw"></i>评论</h6>
                </div>
                <div class="widget-body">
                    <?php if($comments->isEmpty()): ?>
                        <h3 class="center-block meta-item">No Comments</h3>
                    <?php else: ?>
                        <table class="table table-striped table-hover table-bordered table-responsive">
                            <thead>
                            <tr>
                                <th>用户</th>
                                <th>Email</th>
                                <th>地址</th>
                                <th>内容</th>
                                <th>IP</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php $commentableData = $comment->getCommentableData();?>

                                <tr class="<?php echo e($comment->trashed() ? 'danger':''); ?>">
                                    <td>
                                        <?php if($comment->user_id): ?>
                                            <a href="<?php echo e(route('user.show',$comment->username)); ?>"><?php echo e($comment->username); ?></a>
                                        <?php else: ?>
                                            <?php echo e($comment->username); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><a href="mailto:<?php echo e($comment->email); ?>"><?php echo e($comment->email); ?></a></td>
                                    <td>
                                        <?php if($commentableData['deleted']): ?>
                                            <?php echo e($commentableData['type']); ?> Deleted
                                        <?php else: ?>
                                            <?php if($comment->trashed()): ?>
                                                <?php echo e($commentableData['title']); ?>

                                            <?php else: ?>
                                                <a target="_blank"
                                                   href="<?php echo e($commentableData['url']); ?>"><?php echo e($commentableData['title']); ?>

                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td data-toggle="tooltip" data-placement="top"
                                        title="<?php echo e($comment->content); ?>"><?php echo $comment->html_content; ?></td>
                                    <td><?php echo e($comment->ip_id?$comment->ip_id:'NONE'); ?></td>
                                    <td>
                                        <?php if($comment->trashed()): ?>
                                            <button type="submit"
                                                    class="btn btn-danger swal-dialog-target"
                                                    data-dialog-msg="永久删除这条评论？"
                                                    data-url="<?php echo e(route('comment.destroy',[$comment->id,'force'=>'true'])); ?>"
                                                    data-method="delete"
                                                    data-placement="top"
                                                    title="永久删除">
                                                <i class="fa fa-trash-o fa-fw"></i>
                                            </button>
                                            <form style="display: inline-block" method="post"
                                                  action="<?php echo e(route('comment.restore',$comment->id)); ?>">
                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-primary"
                                                        data-toggle="tooltip" data-placement="top" title="恢复">
                                                    <i class="fa fa-repeat fa-fw"></i>
                                                </button>
                                            </form>

                                        <?php else: ?>
                                            <button type="submit"
                                                    class="btn btn-danger swal-dialog-target"
                                                    data-dialog-msg="确定删除此评论？"
                                                    data-url="<?php echo e(route('comment.destroy',$comment->id)); ?>"
                                                    title="删除">
                                                <i class="fa fa-trash-o fa-fw"></i>
                                            </button>
                                            <a class="btn btn-info"
                                               href="<?php echo e(route('comment.edit',[$comment->id,'redirect'=>request()->fullUrl()])); ?>">
                                                <i class="fa fa-pencil fa-fw"></i>
                                            </a>
                                        <?php endif; ?>
                                        <?php $ip = $comment->ip ?>
                                        <?php if($ip == null): ?>
                                            <button disabled
                                                    class="btn btn-default"
                                                    title="NO IP">
                                                <i class="fa fa-close fa-fw"></i>
                                            </button>
                                        <?php else: ?>
                                            <?php echo $__env->make('admin.partials.ip_button',['ip'=>$ip], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php if($comments->lastPage() > 1): ?>
                            <?php echo e($comments->links()); ?>

                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>