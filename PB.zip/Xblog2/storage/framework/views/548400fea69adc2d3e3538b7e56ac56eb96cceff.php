<?php $__env->startSection('title','设置'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <form role="form" id="setting-form" class="form-horizontal" action="<?php echo e(route('admin.save-settings')); ?>"
              method="post">
            <div class="widget widget-default">
                <div class="widget-header">
                    <h6>
                        <i class="fa fa-cog fa-fw"></i>设置
                    </h6>
                </div>
                <div class="widget-body">
                    <div class="form-group">
                        <div class="radio">
                            <label class="col-sm-offset-2">
                                <input type="radio"
                                       <?php echo e(isset($google_analytics) && $google_analytics == 'true' ? ' checked ':''); ?>

                                       name="google_analytics"
                                       value="true">启用谷歌分析
                            </label>
                        </div>
                        <div class="radio">
                            <label class="col-sm-offset-2">
                                <input type="radio"
                                       <?php echo e(isset($google_analytics) && $google_analytics == 'true' ? '':' checked '); ?>

                                       name="google_analytics"
                                       value="false">禁用谷歌分析
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="radio">
                            <label class="col-sm-offset-2">
                                <input type="radio"
                                       <?php echo e(isset($enable_mail_notification) && $enable_mail_notification == 'true' ? ' checked ':''); ?>

                                       name="enable_mail_notification"
                                       value="true">启用邮件通知
                            </label>
                        </div>
                        <div class="radio">
                            <label class="col-sm-offset-2">
                                <input type="radio"
                                       <?php echo e(isset($enable_mail_notification) && $enable_mail_notification == 'true' ? '':' checked '); ?>

                                       name="enable_mail_notification"
                                       value="false">禁用邮件通知
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="radio">
                            <label class="col-sm-offset-2">
                                <input type="radio"
                                       <?php echo e((isset($comment_type) && $comment_type == 'none') ? ' checked ':''); ?>

                                       name="comment_type"
                                       value="none">关闭评(不显示)
                            </label>
                        </div>
                        <div class="radio">
                            <label class="col-sm-offset-2">
                                <input type="radio"
                                       <?php echo e((!isset($comment_type) || $comment_type == 'raw') ? ' checked ':''); ?>

                                       name="comment_type"
                                       value="raw">自带评论
                            </label>
                        </div>
                        <div class="radio">
                            <label class="col-sm-offset-2">
                                <input type="radio"
                                       <?php echo e(isset($comment_type) && $comment_type == 'disqus' ? ' checked':''); ?>

                                       name="comment_type"
                                       value="disqus">Disqus
                            </label>
                        </div>
                        <div class="radio">
                            <label class="col-sm-offset-2">
                                <input type="radio"
                                       <?php echo e(isset($comment_type) && $comment_type == 'duoshuo' ? ' checked':''); ?>

                                       name="comment_type"
                                       value="duoshuo">多说
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="radio">
                            <label class="col-sm-offset-2">
                                <input type="radio"
                                       <?php echo e((!isset($allow_comment) || $allow_comment == 'true') ? ' checked ':''); ?>

                                       name="allow_comment"
                                       value="true">允许评论(仍会显示已有评论)
                            </label>
                        </div>
                        <div class="radio">
                            <label class="col-sm-offset-2">
                                <input type="radio"
                                       <?php echo e((isset($allow_comment) && $allow_comment == 'false') ? ' checked ':''); ?>

                                       name="allow_comment"
                                       value="false">禁止评论(仍会显示已有评论)
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="radio">
                            <label class="col-sm-offset-2">
                                <input type="radio"
                                       <?php echo e(isset($enable_hot_posts) && $enable_hot_posts == 'true' ? ' checked ':''); ?>

                                       name="enable_hot_posts"
                                       value="true">启用热门文章
                            </label>
                        </div>
                        <div class="radio">
                            <label class="col-sm-offset-2">
                                <input type="radio"
                                       <?php echo e(isset($enable_hot_posts) && $enable_hot_posts == 'true' ? '':' checked '); ?>

                                       name="enable_hot_posts"
                                       value="false">禁用热门文章
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="radio">
                            <label class="col-sm-offset-2">
                                <input type="radio"
                                       <?php echo e(isset($open_pay) && $open_pay == 'true' ? ' checked ':''); ?>

                                       name="open_pay"
                                       value="true">开启赞赏
                            </label>
                        </div>
                        <div class="radio">
                            <label class="col-sm-offset-2">
                                <input type="radio"
                                       <?php echo e(isset($open_pay) && $open_pay == 'true' ? '':' checked '); ?>

                                       name="open_pay"
                                       value="false">关闭赞赏
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="google_trace_id" class="col-sm-2 control-label">跟踪ID</label>
                        <div class="col-sm-8">
                            <input type="text" name="google_trace_id" class="form-control" id="google_trace_id"
                                   placeholder="谷歌跟踪ID"
                                   value="<?php echo e(isset($google_trace_id) ? $google_trace_id : ''); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="author" class="col-sm-2 control-label">作者</label>
                        <div class="col-sm-8">
                            <input type="text" name="author" class="form-control" id="author"
                                   value="<?php echo e(isset($author) ? $author : ''); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="description" class="col-sm-2 control-label">描述</label>
                        <div class="col-sm-8">
                            <input type="text" name="description" class="form-control" id="description"
                                   value="<?php echo e(isset($description) ? $description : ''); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="avatar" class="col-sm-2 control-label">头像</label>
                        <div class="col-sm-8">
                            <input type="text" name="avatar" class="form-control" id="avatar"
                                   value="<?php echo e(isset($avatar) ? $avatar : ''); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="avatar" class="col-sm-2 control-label">Disqus ID</label>
                        <div class="col-sm-8">
                            <input type="text" name="disqus_shortname" class="form-control" id="avatar"
                                   value="<?php echo e(isset($disqus_shortname) ? $disqus_shortname : ''); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="avatar" class="col-sm-2 control-label">多说 ID</label>
                        <div class="col-sm-8">
                            <input type="text" name="duoshuo_shortname" class="form-control" id="avatar"
                                   value="<?php echo e(isset($duoshuo_shortname) ? $duoshuo_shortname : ''); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="avatar" class="col-sm-2 control-label">Github用户名</label>
                        <div class="col-sm-8">
                            <input type="text" name="github_username" class="form-control" id="avatar"
                                   value="<?php echo e(isset($github_username) ? $github_username : ''); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Js</label>
                        <div class="col-sm-8">
                            <input class="form-control" type="text" name="site_js"
                                   value="<?php echo e(isset($site_js) ? $site_js : ''); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Css</label>
                        <div class="col-sm-8">
                            <input class="form-control" type="text" name="site_css"
                                   value="<?php echo e(isset($site_css) ? $site_css : ''); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">标题</label>
                        <div class="col-sm-8">
                            <input class="form-control" type="text" name="site_title"
                                   value="<?php echo e(isset($site_title) ? $site_title : ''); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">关键字</label>
                        <div class="col-sm-8">
                            <input placeholder="网站关键字" class="form-control" type="text" name="site_keywords"
                                   value="<?php echo e(isset($site_keywords) ? $site_keywords : ''); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">网站描述</label>
                        <div class="col-sm-8">
                            <input class="form-control" type="text" name="site_description"
                                   value="<?php echo e(isset($site_description) ? $site_description : ''); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">每页数量</label>
                        <div class="col-sm-8">
                            <input class="form-control" type="number" name="page_size"
                                   value="<?php echo e(isset($page_size) ? $page_size : 7); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">热门文章数量</label>
                        <div class="col-sm-8">
                            <input class="form-control" type="number" name="hot_posts_count"
                                   value="<?php echo e(isset($hot_posts_count) ? $hot_posts_count : 5); ?>">
                        </div>
                    </div>


                    <div class="form-group">
                        <label class="col-sm-2 control-label">简介图片</label>
                        <div class="col-sm-8">
                            <input class="form-control" type="text" name="profile_image"
                                   value="<?php echo e(isset($profile_image) ? $profile_image : ''); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">背景图片</label>
                        <div class="col-sm-8">
                            <input class="form-control" type="text" name="background_image"
                                   value="<?php echo e(isset($background_image) ? $background_image : ''); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">赞赏描述</label>
                        <div class="col-sm-8">
                            <input class="form-control" type="text" name="pay_description"
                                   value="<?php echo e(isset($pay_description) ? $pay_description : '写的不错，赞助一下主机费'); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">支付宝支付二维码</label>
                        <div class="col-sm-8">
                            <input class="form-control" type="text" name="zhifubao_pay_image_url"
                                   value="<?php echo e(isset($zhifubao_pay_image_url) ? $zhifubao_pay_image_url : ''); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">微信支付二维码</label>
                        <div class="col-sm-8">
                            <input class="form-control" type="text" name="wechat_pay_image_url"
                                   value="<?php echo e(isset($wechat_pay_image_url) ? $wechat_pay_image_url : ''); ?>">
                        </div>
                    </div>

                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <div class="col-sm-8 col-sm-offset-2">
                            <button type="submit" class="btn bg-primary">
                                保存
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>