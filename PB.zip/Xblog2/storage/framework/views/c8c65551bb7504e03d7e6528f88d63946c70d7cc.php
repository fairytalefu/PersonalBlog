<?php $__env->startSection('title','IPs'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="widget widget-default">
                <div class="widget-header">
                    <h6>
                        <i class="fa fa-internet-explorer fa-fw"></i>
                        IP
                        <a class="meta-item" href="<?php echo e(route('admin.ips',['blocked'=>1])); ?>">Blocked</a>
                    </h6>
                </div>
                <div class="widget-body">
                    <?php if($ips->isEmpty()): ?>
                        <div style="text-align: center;"> -_- NO IP.</div>
                    <?php else: ?>
                        <table class="table table-hover table-striped table-bordered table-responsive"
                               style="overflow: auto">
                            <thead>
                            <tr>
                                <th>IP</th>
                                <th>Last User</th>
                                <th>评论数</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $ips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($ip->id); ?></td>
                                    <?php if($ip->user): ?>
                                        <td>
                                            <a href="<?php echo e(route('user.show',$ip->user->name)); ?>"><?php echo e($ip->user->name); ?></a>
                                            <?php if(isAdminById($ip->user_id)): ?>
                                                <span class="role-label">Admin</span>
                                            <?php endif; ?>
                                        </td>
                                    <?php else: ?>
                                        <td>NONE</td>
                                    <?php endif; ?>
                                    <td><?php echo e($ip->comments_count); ?></td>
                                    <td>
                                        <?php echo $__env->make('admin.partials.ip_button',['ip'=>$ip], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        <button class="btn btn-info swal-dialog-target"
                                                data-url="<?php echo e(route('ip.delete',$ip->id)); ?>"
                                                data-dialog-msg="确定删除IP<?php echo e($ip->id); ?>?">
                                            <i class="fa fa-trash-o fa-fw"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php if($ips->lastPage() > 1): ?>
                            <?php echo e($ips->links()); ?>

                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>