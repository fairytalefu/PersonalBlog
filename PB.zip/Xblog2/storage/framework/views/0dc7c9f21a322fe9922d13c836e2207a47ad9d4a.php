<button class="btn swal-dialog-target <?php echo e($ip->blocked?' btn-danger':' btn-default'); ?>"
        data-dialog-msg="<?php echo e($ip->blocked?'取消阻塞':'阻塞'); ?> IP <?php echo e($ip->id); ?> ?<?php echo e($ip->blocked?'':'阻塞后此IP将不能访问你的网站'); ?>"
        data-url="<?php echo e(route('ip.block',$ip->id)); ?>"
        data-dialog-title="<?php echo e($ip->blocked?'取消阻塞':'阻塞'); ?>"
        title="<?php echo e($ip->blocked?'Un Block':'Block'); ?>">
    <i class="fa <?php echo e($ip->blocked?'fa-check':'fa-close'); ?> fa-fw"></i>
</button>