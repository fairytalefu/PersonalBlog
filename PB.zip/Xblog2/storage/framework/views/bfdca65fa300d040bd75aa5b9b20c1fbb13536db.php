<?php $__env->startSection('content'); ?>
    <div id="particles" class="home-color-bg"></div>
    <div class="home-box">
        <h2 title="<?php echo e(isset($site_title) ? $site_title : 'title'); ?>" style="margin: 0;">
            <?php echo e(isset($site_title) ? $site_title : 'FZU个人博客'); ?>

            <a aria-hidden="true" href="<?php echo e(route('post.index')); ?>">
                <img class="img-circle" src="<?php echo e(isset($avatar) ? $avatar : '/laravel.jpg'); ?>" alt="<?php echo e(isset($author) ? $author : 'Author'); ?>">
            </a>

        </h2>
        <h3 title="<?php echo e(isset($description) ? $description : 'description'); ?>" aria-hidden="true" style="margin: 0">
            <?php echo e(isset($description) ? $description : 'Stay Hungry. Stay Foolish.'); ?>

        </h3>
        <p class="links">
            <font aria-hidden="true">»</font>
            <a href="<?php echo e(route('post.index')); ?>" aria-label="点击查看博客文章列表">博客</a>
            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <font aria-hidden="true">/</font><a href="<?php echo e(route('page.show',$page->name)); ?>"
                                                    aria-label="查看<?php echo e(isset($author) ? $author : 'author'); ?>的<?php echo e($page->display_name); ?>"><?php echo e($page->display_name); ?></a>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </p>
        <p class="links">
            <font aria-hidden="true">»</font>
            <?php $__currentLoopData = config('social'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($value['url']); ?>" target="_blank"
                   aria-label="<?php echo e(isset($author) ? $author : 'author'); ?> 的 <?php echo e(ucfirst($key)); ?> 地址">
                    <i class="<?php echo e($value['fa']); ?>" title="<?php echo e(ucfirst($key)); ?>"></i>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
    <script src="js/particles.min.js"></script>
    <script>
        particlesJS('particles',
                {particles:{number:{value:80,density:{enable:!0,value_area:1E3}},color:{value:"#ffff33"},shape:{type:"polygon",stroke:{width:0,color:"#ffff33"},polygon:{nb_sides:5}},opacity:{value:.5,random:!1,anim:{enable:!1,speed:1,opacity_min:.1,sync:!1}},size:{value:15,random:!0,anim:{enable:!1,
                    speed:180,size_min:.1,sync:!1}},line_linked:{enable:!0,distance:650,color:"#0f0f0f",opacity:.26,width:1},move:{enable:!0,speed:12,direction:"none",random:!0,straight:!1,out_mode:"out",bounce:!1,attract:{enable:!1,rotateX:600,rotateY:1200}}},interactivity:{detect_on:"canvas",events:{onhover:{enable:1,mode:"repulse"},onclick:{enable:0,mode:"push"},resize:!0},modes:{grab:{distance:400,line_linked:{opacity:1}},bubble:{distance:400,size:40,duration:2,opacity:8,speed:3},repulse:{distance:200,duration:.4},
                    push:{particles_nb:4},remove:{particles_nb:2}}},retina_detect:!0}
        );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>