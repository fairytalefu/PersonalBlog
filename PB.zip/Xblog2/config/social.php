<?php

return [
/**
 * Created by PhpStorm.
 * User: lufficc
 * Date: 2016/8/21
 * Time: 22:47
 */
    'facebook' => [
        'url'  => '#',
        'fa'   => 'fa fa-facebook fa-fw',
    ],
    'twitter'  => [
        'url'  => '#',
        'fa'   => 'fa fa-twitter fa-fw',
    ],
    'weibo'    => [
        'url'  => 'http://weibo.com/u/2363498941',
        'fa'   => 'fa fa-weibo fa-fw',
    ],
    'github'  => [
        'url' =>'https://github.com/fairytalefu',
        'fa'   => 'fa fa-github fa-fw',
    ],

];